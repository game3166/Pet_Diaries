package spring.model;

public interface CommInterface {

	public long interfaceId = 0;
	public long ownerID = 0;
	public long caretaketId = 0;
	
	
}
