package spring.model;

public class Login {

}
