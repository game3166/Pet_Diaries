package spring.controllers;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.object.RdbmsOperation;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import spring.model.User;
import spring.model.CommInterface;
import spring.model.Request;
import spring.service.CommInterfaceService;
import spring.service.RequestService;
import spring.service.UserService;


@Controller
public class CommInterfaceController {

	private CommInterfaceService commInterfaceService;
	private RequestService requestService;
	private UserService userService;
	
	@Autowired(required=true)
	public void setCommInterfaceService(CommInterfaceService ps){
		System.out.println("In CommInterface controller");
		this.commInterfaceService = ps;
	}
	
	@Autowired(required=true)
	public void setRequestService(RequestService r){
		System.out.println("In CommInterface controller");
		this.requestService = r;
	}
	
	@Autowired(required=true)
	public void setUserService(UserService u){
		System.out.println("In CommInterface controller");
		this.userService = u;
	}
	
	@GetMapping("/chatBox")
	public String welcome(Model model)
	  {
		return "chatBox";
	  }
	
	@RequestMapping(value = "/user/CommInterface")
	public String showTable(Model model){
		
		model.addAttribute("CommInterfaces", new CommInterface());
		model.addAttribute("listCommInterfaces", this.commInterfaceService.listCommInterfaces());
		
		return "CommInterface";
	}
	
	@RequestMapping(value = "/CommInterface/addCaretaker")
	public String addCommInterface(Model model, @RequestParam("caretakerIdTemp") int careTakerIdTemp, @RequestParam("requestId") int requestId){
		
		System.out.println("Received request" + requestId);
		System.out.println("Caretaker is :" + careTakerIdTemp);
	
		Request request = this.requestService.getRequestById(requestId);
		
	
		    CommInterface C;
		    C = new CommInterface();
	        C.setOwnerId(request.getOwnerId());
	        C.setRequestId(request.getRequestId());
	        C.setCaretakerId(careTakerIdTemp);
	        
		    this.commInterfaceService.addCommInterface(C);
		
			 
		return "message";
	}
	
/*	@RequestMapping(value = "/CommInterface/goToProfile")
	public String goToProfile(Model model, @RequestParam("caretakerIdTemp") int careTakerIdTemp)
	{
		User u = this.userService.getUserById(careTakerIdTemp);
		return null;
	}*/
	
	@RequestMapping(value = "/CommInterface/caretakerSelect", method = RequestMethod.POST)
	public String caretakerSelect(Model model, 
			@RequestParam("commInterfaceId") int commInterfaceId,
			@RequestParam("requestId") int requestId,
			@RequestParam("username") String username,
			@RequestParam("userId") int userId,
			@RequestParam("lastName") String lastName,
			@RequestParam("firstName") String firstName,
			@RequestParam("userType") String userType,
			@ModelAttribute("user") User u1,
			RedirectAttributes ra)
		{
		CommInterface C = this.commInterfaceService.getCommInterfaceById(commInterfaceId);
		System.out.println("interface id"+C.getInterfaceId());
		C.setSelectCaretaker(true);
		this.commInterfaceService.updateCommInterface(C);
		int j;
		List<CommInterface> cList = this.commInterfaceService.getCommInterfaceListByRequestId(requestId);
	    System.out.println("List"+cList);
		if(cList.isEmpty() == false)
		{
		for(j=0;j<cList.size();j++)
		{
		
			
			if(cList.get(j).isSelectCaretaker() == false)
			{
				System.out.println("Comm Interface: "+cList.get(j).getInterfaceId());	
				this.commInterfaceService.removeCommInterface((int)(cList.get(j).getInterfaceId()));
			}
		}
		}
		
		User u=new User();
		u.setUsername(username);
		u.setUserId(userId);
		u.setLastName(lastName);
		u.setFirstName(firstName);
		u.setUserType(userType);
		ra.addFlashAttribute("user", u);
		
		return "redirect:/user/dash";
	}
	
    @RequestMapping(value= "/CommInterface/nextPageChatBox", method = RequestMethod.GET)
	public String nextPageChatBox(Model model, @RequestParam("username") String username,  HttpServletResponse response,HttpServletRequest request)
	{
    	HttpSession usersession = request.getSession();
    	System.out.println(username + "/n");
    	usersession.setAttribute("user",username);
    	return "redirect:/chatBox";
	}
    
    @RequestMapping(value= "/CommInterface/acceptAgreement", method = RequestMethod.GET)
   	public String setAgreement(Model model, @RequestParam("commInterfaceId") int commInterfaceId)
   	{
    	CommInterface C = this.commInterfaceService.getCommInterfaceById(commInterfaceId);
        C.setAgreementStatusOwner(true);
        this.commInterfaceService.updateCommInterface(C);
       	
       	return "message";
   	}
    
    
    @RequestMapping(value= "/CommInterface/acceptAgreementCaretaker", method = RequestMethod.GET)
   	public String setAgreementCaretaker(Model model, @RequestParam("commInterfaceId") int commInterfaceId)
   	{
    	CommInterface C = this.commInterfaceService.getCommInterfaceById(commInterfaceId);
        C.setAgreementStatusCaretaker(true);
        this.commInterfaceService.updateCommInterface(C);
       	
       	return "message";
   	}
}