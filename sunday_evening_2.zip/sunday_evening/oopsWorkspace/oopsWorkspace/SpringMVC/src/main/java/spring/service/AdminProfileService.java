package spring.service;

import java.util.Date;
import java.util.List;

import spring.model.AdminProfile;
import spring.model.ContactInfo;
import spring.model.Request;
import spring.model.ResetToken;
import spring.model.User;

public interface AdminProfileService
{

	public List<Request> listRequestInAdmin();
	public String isEmailAddrAvailable(ContactInfo c,int id);
	public List<String> testfunc();

	public List<User> listUsersNotAuthenticated();
	public boolean addAdminProfile(AdminProfile p);
	public boolean validateAdminProfile(AdminProfile p);
	public void updateAdminProfile(AdminProfile p);
	public List<AdminProfile> listAdminProfiles();
	public AdminProfile getAdminProfileById(int id);
	public void removeAdminProfile(int id);
	public int getAdminProfileCount(int id);
	public boolean isContactInfoSet(int id);
	public List<String> getExpiredEmails();
	public void deleteExpiredProfiles();
}