package spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DB1.COMMINTERFACE", uniqueConstraints= @javax.persistence.UniqueConstraint(columnNames={"requestId", "caretakerId"}))
public class CommInterface {
	
	@Id
	@Column(name="interfaceId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int interfaceId;
	
	@Column
	private int requestId;	
	
    private int ownerId;
	
	private int caretakerId;
	
    private boolean agreementStatusOwner= false;
	
    private boolean agreementStatusCaretaker= false;
    
    private boolean selectCaretaker = false;
    
    public boolean isSelectCaretaker() {
		return selectCaretaker;
	}

	public void setSelectCaretaker(boolean selectCaretaker) {
		this.selectCaretaker = selectCaretaker;
	}
	
	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public int getCaretakerId() {
		return caretakerId;
	}

	public void setCaretakerId(int caretakerId) {
		this.caretakerId = caretakerId;
	}


	public boolean isAgreementStatusOwner() {
		return agreementStatusOwner;
	}

	public void setAgreementStatusOwner(boolean agreementStatusOwner) {
		this.agreementStatusOwner = agreementStatusOwner;
	}

	public boolean isAgreementStatusCaretaker() {
		return agreementStatusCaretaker;
	}

	public void setAgreementStatusCaretaker(boolean agreementStatusCaretaker) {
		this.agreementStatusCaretaker = agreementStatusCaretaker;
	}
	
	public int getInterfaceId() {
		return interfaceId;
	}

	public void setInterfaceId(int interfaceId) {
		this.interfaceId = interfaceId;
	}

	

	
	

}
