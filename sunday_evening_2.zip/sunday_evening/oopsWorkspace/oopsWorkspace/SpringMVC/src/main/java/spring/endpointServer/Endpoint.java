package spring.endpointServer;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import javax.websocket.Session;
import javax.json.Json;
import javax.json.JsonObject;

@ServerEndpoint(value = "/chat")
public class Endpoint {
   
	static Set<Session> chatroomusers = Collections.synchronizedSet(new HashSet<Session>()); 
	
	@OnOpen
	public void handleOpen(Session usersession)
	{
		chatroomusers.add(usersession);
		System.out.println("Server Response: Client is Connected...");
	}
	
	@OnMessage
	public String handleMessage(String Msg, Session usersession) throws IOException
	{
		String username = (String)usersession.getUserProperties().get("username");
		System.out.println("Server response: "+ username + ":" + Msg);
		String eMsg = Msg;
		
		if(username == null)
		{
			usersession.getUserProperties().put("username", Msg);
			
			usersession.getBasicRemote().sendText("System: you are now connected as: "+ Msg);
			return Msg;
		}
		else{
			Iterator<Session> iterator = chatroomusers.iterator();
			
			while(iterator.hasNext()) iterator.next().getBasicRemote().sendText(username+":"+Msg);
			return Msg;
		}
		
	}
	
	@OnClose
	public void handleClose(Session usersession) throws IOException
	{
		chatroomusers.remove(usersession);
		System.out.println("Server Response: Client is Disconnected...");
		
	}
	
	@OnError
	public void handleError(Throwable t)
	{
		t.printStackTrace();
	}
	
	private String buildJsonData(String username,String message)
	{
		JsonObject jsonObject = Json.createObjectBuilder().add("message",username+":"+message).build();
		return null;
	}
}