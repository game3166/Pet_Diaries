package spring.controllers;

import java.util.List;

import spring.service.PetService;
import spring.service.ContactInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import spring.model.Pet;
import spring.model.Request;
import spring.model.User;
import spring.service.OwnerProfileService;

@Controller
public class OwnerProfileController {
	
	private OwnerProfileService ownerProfileService;
	
	@Autowired(required=true)
	//@Qualifier(value="ownerProfileService")
	public void setOwnerProfileService(OwnerProfileService ps){
		System.out.println("In owner profile");
		this.ownerProfileService = ps;
	}
	
	@Autowired(required=true)
	//@Qualifier(value="ownerProfileService")
	public void setContactInfoService(ContactInfoService ps){
		System.out.println("In owner profile");
		this.contactInfoService = ps;
	}
	
	@Autowired(required=true)
	//@Qualifier(value="ownerProfileService")
	public void setPetService(PetService ps){
		System.out.println("In owner profile");
		this.petService = ps;
	}	
	
	@RequestMapping(value = "/user/login/request/{id}/{username}/{userType}")
	public String createRequest(@ModelAttribute("request") Request r,
			@PathVariable("id") int id,@PathVariable("username") String username,
			@PathVariable("userType") String userType,Model model) {
		model.addAttribute("listPets", this.ownerProfileService.listPetByOwnerId(id));
		model.addAttribute("ownerId", id);
		model.addAttribute("ownerName",username);
		model.addAttribute("userType", userType);
		System.out.println("Owner info " + username);
		System.out.println(id);
	   // return "redirect:/request";
		return "request";
	}
	
	@RequestMapping(value = "/user/login/edit/{id}/{type}")
	public String updateRequest(@ModelAttribute("request") Request r,
			@PathVariable("id") int id,@PathVariable("type") String userType,Model model) {
		
		model.addAttribute("ownerId", id);
		model.addAttribute("userType", userType);		
		model.addAttribute("editrequest",this.ownerProfileService.listRequestByOwnerId(id));
		
		//model.addAttribute("request", r);
		//System.out.println(id);
	   // return "redirect:/request";
		return "request";
	}
	
	@RequestMapping(value = "/user/suggestedCaretakers", method = RequestMethod.GET)
	public String listPets(Model model,@RequestParam("userId") int userId, 
			@RequestParam("firstName") String firstName ) {
	
		System.out.println("In suggested caretakers");
		model.addAttribute("userId",userId);
		model.addAttribute("firstName",firstName);
		model.addAttribute("user",new User());
		model.addAttribute("listCaretakers", this.ownerProfileService.listCaretakers(userId));

		return "suggestedCaretakers";
	}
	
	@RequestMapping(value = "/user/listCaretakers", method = RequestMethod.POST)
	public String listCaretakers(Model model,
			@ModelAttribute("user") User p,
			@RequestParam("userId") int userId,
			@RequestParam("username") String username,
			@RequestParam("userType") String userType,
			@RequestParam("firstName") String firstName
			) {
	
		int contactInfoId=this.contactInfoService.getIdFromUserId(userId);
		
		System.out.println("In list caretakers ");
		model.addAttribute("userId",userId);
		
		model.addAttribute("firstName",firstName);
		model.addAttribute("listContact",this.contactInfoService.getContactInfoById(contactInfoId));
		model.addAttribute("listPetPreferences",this.petService.listPets(userId));
		
		
		/*FActory pattern comes here*/
		return "profile";
	}
	
}