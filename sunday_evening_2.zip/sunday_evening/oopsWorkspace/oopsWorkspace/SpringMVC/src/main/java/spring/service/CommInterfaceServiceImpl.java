package spring.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import spring.dao.CommInterfaceDAO;
import spring.model.CommInterface;

@Service
public class CommInterfaceServiceImpl implements CommInterfaceService{

	private CommInterfaceDAO commInterfaceDAO;
	
	public void setCommInterfaceDAO(CommInterfaceDAO commInterfaceDAO) {
		this.commInterfaceDAO = commInterfaceDAO;
	}

	@Override
	@Transactional
	public boolean addCommInterface(CommInterface C)
	{
		boolean error=false;
		error=this.commInterfaceDAO.addCommInterface(C);
		return error;
		
	}
	
	@Override
	@Transactional
	public void updateCommInterface(CommInterface C)
	{
		this.commInterfaceDAO.updateCommInterface(C);	
	}
	
	@Override
	@Transactional
	public List<CommInterface> listCommInterfaces()
	{
		return this.commInterfaceDAO.listCommInterfaces();
	}
	
	@Override
	@Transactional
	public CommInterface getCommInterfaceById(int id)
	{
		return this.commInterfaceDAO.getCommInterfaceById(id);
	}
	
	@Override
	@Transactional
	public void removeCommInterface(int id)
	{
		this.commInterfaceDAO.removeCommInterface(id);
	}
	
	@Override
	@Transactional
	public int getCommInterfaceCount(int id)
	{
		return this.commInterfaceDAO.getCommInterfaceCount(id);
	}
	
	@Override
	@Transactional
	public boolean isAgreementDone(int id)
	{
		return true;
	}

	
	@Override
	@Transactional
	public List<Integer> getRequestsByOwnerId(int id)
	{
		return this.commInterfaceDAO.getRequestsByOwnerId(id);
	}
	
	@Override
	@Transactional
	public List<Integer> getCaretakerByRequestId(int id)
	{
		return this.commInterfaceDAO.getCaretakerByRequestId(id);
	}

	@Override
	@Transactional
	public List<CommInterface> getTableByOwnerId(int id)
	{
		return this.commInterfaceDAO.getTableByOwnerId(id);
	}
	
	@Override
	@Transactional
	public List<CommInterface> getCommInterfaceListByRequestId(int id)
	{
		return this.commInterfaceDAO.getCommInterfaceListByRequestId(id);
	}
	
	@Override
	@Transactional
	public List<CommInterface> getTableByCaretakerId(int id)
	{
		return this.commInterfaceDAO.getTableByCaretakerId(id);
	}

}