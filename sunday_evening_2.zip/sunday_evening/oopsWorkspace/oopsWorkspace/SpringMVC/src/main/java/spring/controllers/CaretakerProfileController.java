package spring.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import spring.model.Request;
import spring.service.CaretakerProfileService;

@Controller
public class CaretakerProfileController {
	
	private CaretakerProfileService CaretakerProfileService;
	
	@Autowired(required=true)
	//@Qualifier(value="CaretakerProfileService")
	public void setCaretakerProfileService(CaretakerProfileService ps){
		System.out.println("In caretaker profile");
		this.CaretakerProfileService = ps;
	}
	
	@RequestMapping(value = "/user/viewProfile")
	public String createRequest(@ModelAttribute("request") Request r, Model model) {
		System.out.println("Here it is......");
		
	
	   // return "redirect:/request";
		return "profile";
	}
	
}