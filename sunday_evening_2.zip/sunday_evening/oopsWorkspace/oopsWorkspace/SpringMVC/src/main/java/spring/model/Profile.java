package spring.model;


import spring.model.User;
import spring.service.ProfileFactoryService;


public abstract class Profile extends User{
	
	private String dashboard;

	public String getDashboard() {
		return dashboard;
	}

	public void setDashboard(String dashboard) {
		this.dashboard = dashboard;
	}
	
	
}