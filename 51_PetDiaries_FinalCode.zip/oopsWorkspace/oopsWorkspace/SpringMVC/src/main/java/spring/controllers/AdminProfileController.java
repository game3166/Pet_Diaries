package spring.controllers;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import spring.model.AdminProfile;
import spring.model.ContactInfo;
import spring.model.Pet;
import spring.model.Request;
import spring.model.ResetToken;
import spring.model.User;
import spring.service.ProfileFactoryService;
import spring.service.AdminProfileService;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
@Controller
public class AdminProfileController {
	
	private AdminProfileService adminProfileService;
	//private ProfileFactoryService profileFactoryService;
	
	@Autowired(required=true)
	//@Qualifier(value="adminProfileService")
	public void setAdminProfileService(AdminProfileService ps){
		System.out.println("In adminProfile controller");
		this.adminProfileService = ps;
		
	}
	
	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String listRequestInAdmin(@ModelAttribute("request") Request r,Model model) {
		
		return "redirect:/request";
	}
	
	
	
	@RequestMapping(value = "/admin/email", method = RequestMethod.POST)
	public String authenticateEmail(Model model, @ModelAttribute("user") User u,@ModelAttribute("contact") ContactInfo c){ 
		
		System.out.println("Email in Process");
		
		/*List<String>l1=this.adminProfileService.testfunc();
		if(l1!=null)
		System.out.println(l1);*/
		
		List<User>us=this.adminProfileService.listUsersNotAuthenticated();
		//if(us!=null)
		//System.out.println(us);
		for(User newUser : us)
		{
			if(!(newUser.getUserType().matches("Admin")))
		    {  System.out.println("");
			   System.out.print(newUser.getUserId());
			   String emailaddr=this.adminProfileService.isEmailAddrAvailable(c,newUser.getUserId());
			   if(!(emailaddr.isEmpty()))
			   {
				 String username=newUser.getUsername();
				 System.out.println("Username: " +username);

				  String to = emailaddr;

			      // Sender's email ID needs to be mentioned
			      String from = "from@no-spam.com";

			      // Assuming you are sending email from localhost
			      String host = "smtp.gmail.com";

			      // Get system properties
			      Properties properties = System.getProperties();

			      // Setup mail server
			      properties.setProperty("mail.smtp.host", host);

			      properties.setProperty("mail.smtp.socketFactory.port", "465");
			      properties.setProperty("mail.smtp.socketFactory.class",
							"javax.net.ssl.SSLSocketFactory");
			      properties.setProperty("mail.smtp.auth", "true");
			      properties.setProperty("mail.smtp.port", "465");
			      
			      properties.setProperty("mail.smtp.socketFactory.fallback", "false");
			      properties.setProperty("mail.smtp.user", emailaddr);
			      properties.setProperty("mail.smtp.starttls.enable","true");
			      properties.setProperty("mail.smtp.debug", "true");


			     			      
			      // Get the default Session object.
			      Session session = Session.getDefaultInstance(properties,new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication("temppetdiaries","petpetpet!!!");
						}
					});

			      try {
			         // Create a default MimeMessage object.
			         MimeMessage message = new MimeMessage(session);

			         // Set From: header field of the header.
			         message.setFrom(new InternetAddress(from));

			         // Set To: header field of the header.
			         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			         // Set Subject: header field
			         message.setSubject("Authenticate Account - Pet Diaries");

			         String resetUrl="http://localhost:8080/SpringMVC/authenticate/"
								+username;
			         // Now set the actual message
			         message.setText("Hello  "+username+"!\nClick "
	    					+ "the following link to authenticate your account\n"+resetUrl+"\n\nThank You!\n\n-Pet Diaries");

			         // Send message
			         Transport.send(message);
			         System.out.println("Sent message successfully....");
			      }catch (MessagingException mex) {
			         mex.printStackTrace();
			      }
				 
			   }
			   model.addAttribute("emailSent",true);
		    }
		}
        	
		
		return "authenticate";
      
	}
	
	@RequestMapping(value = "/admin/back", method = RequestMethod.POST)
	public String listRequestInAdmin(Model model) {
		
		return "adminDashboard";
	}
	
	@RequestMapping(value = "/admin/sendExpiryEmail")
	public String sendExpiryEmail(Model model,
			@RequestParam("userType") String userType,
			@RequestParam("userId") int userId,
			@RequestParam("firstName") String firstName,
			@RequestParam("username") String username,
			@RequestParam("lastName") String lastName,
			@ModelAttribute("admin") User u,
			RedirectAttributes ra) {
		
	
		String emailContent="Hello,\nYour account with Pet Diaries has not been accessed for more than"
				+ "1 year. Pet diaries will be deleting your account if not activated within the next 2 days."
				+"\nThanks You\nThe Pet Diaries Team";
		System.out.println("In send expiry email");
		
		List <String> emailAddr=this.adminProfileService.getExpiredEmails();
		
		for(String s: emailAddr)
		{
			
			System.out.println("s is "+s);
			Properties props = new Properties();
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.socketFactory.port", "465");
			props.put("mail.smtp.socketFactory.class",
					"javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", "465");
			
			

			Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication("temppetdiaries","petpetpet!!!");
					}
				});

			try {
				
				Message message = new MimeMessage(session);
				message.setFrom(new InternetAddress("from@no-spam.com"));
				message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(s));
				message.setSubject("Account Recovery");
				message.setText(emailContent);

				Transport.send(message);
				System.out.println("Done");

			} catch (MessagingException e) {
				throw new RuntimeException(e);
			}
		}
	   // return "redirect:/request";
		
		model.addAttribute("sentEmail",true);
		User u1=new User();
		u1.setUsername(username);
		u1.setLastName(lastName);
		u1.setUserId(userId);
		u1.setFirstName(firstName);
		u1.setUserType(userType);
		ra.addAttribute("sentEmail",true);
		ra.addFlashAttribute("user", u1);
		return "redirect:/user/dash";
	}
	
	

	@RequestMapping(value = "/admin/deleteExpiredUsers")
	public String deleteExpiredUsers(Model model,
			@RequestParam("userType") String userType,
			@RequestParam("userId") int userId,
			@RequestParam("firstName") String firstName,
			@RequestParam("username") String username,
			@ModelAttribute("admin") User u,
			@RequestParam("lastName") String lastName,
			RedirectAttributes ra) {
	
	
		this.adminProfileService.deleteExpiredProfiles();
	   // return "redirect:/request";

		ra.addAttribute("deletedExpired",true);
		User u1=new User();
		u1.setUsername(username);
		u1.setFirstName(firstName);
		u1.setUserId(userId);
		u1.setUserType(userType);
		u1.setLastName(lastName);
	
		ra.addFlashAttribute("user", u1);
		return "redirect:/user/dash";
	}
	

 	
}