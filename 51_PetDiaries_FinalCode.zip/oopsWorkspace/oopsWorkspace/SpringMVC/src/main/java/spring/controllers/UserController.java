package spring.controllers;


import java.util.ArrayList;
import java.util.Date;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import spring.model.User;
import spring.model.Pet;
import spring.model.CommInterface;
import spring.service.CommInterfaceService;
import spring.model.ResetToken;
import spring.service.ProfileFactoryService;
import spring.model.Profile;
import spring.model.Request;
import spring.service.UserService;
import java.util.List;
@Controller
public class UserController {
	
	private UserService userService;
	private ProfileFactoryService profileFactoryService;
	private CommInterfaceService commInterfaceService;
	@Autowired(required=true)
	//@Qualifier(value="userService")
	public void setUserService(UserService ps){
		System.out.println("In user controller");
		this.userService = ps;
	}
	
	@Autowired(required=true)
	//@Qualifier(value="userService")
	public void setProfileFactoryService(ProfileFactoryService ps){
		System.out.println("In profile factory service setup");
		this.profileFactoryService = ps;
	}
	
	@Autowired(required=true)
	//@Qualifier(value="userService")
	public void setCommInterfaceService(CommInterfaceService c){
		System.out.println("In user controller");
		this.commInterfaceService = c;
	}
	
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public String listUsers(Model model) {
		System.out.println("In listUsers");
		model.addAttribute("user", new User());
		model.addAttribute("listUsers", this.userService.listUsers());
		return "user";
	}
	

	//For add and update user both
	@RequestMapping(value= "/user/add", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("user") User p){
		
		boolean error=false;
		System.out.println("In addUsers"+p.getUsername() +" "+ p.getPassword());
		//if(p.getId() == 0){
			//new user, add it
			error=this.userService.addUser(p);
			
			if(error)
			{
				return "invalid-username";
			}
			else
			{
				return "register-success";
			}
		//}else{
			//existing user, call update
			//this.userService.updateUser(p);
		//}
		
	}
	
	@RequestMapping("/remove/{userId}")
    public String removeUser(@PathVariable("userId") int id){
		
        this.userService.removeUser(id);
        return "redirect:/users";
    }
 
    @RequestMapping("/edit/{userId}")
    public String editUser(@PathVariable("userId") int id, Model model){
        model.addAttribute("user", this.userService.getUserById(id));
        model.addAttribute("listUsers", this.userService.listUsers());
        return "user";
    }
    
    @RequestMapping(value = "/redirect", method = RequestMethod.GET)
    public String redirect() {
       return "redirect:signUp";
    }
   
    
    @RequestMapping(value = "/signUp", method = RequestMethod.GET)
    public String finalPage(@ModelAttribute("user") User p) {
       return "signup";
    }
    
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
       return "redirect:users";
    }
    
    @RequestMapping(value = "/user/goToLogin", method = RequestMethod.GET)
    public String goToLogin(@ModelAttribute("user") User u) {
    	
       return "user";
    }
    
    @RequestMapping(value= "/user/login", method = RequestMethod.POST)
	public String loginUser(Model model, @ModelAttribute("user") User p){
    	
   // 	System.out.println("in login");
    	boolean retVal=this.userService.validateUser(p);
		int userId=0;
    	if(!retVal)
    	{
    	//	System.out.println("Doesn't exist");
    		if(p!=null && p.getError()!=null)
    		{
    			
		    		if(p.getError().equals("Password"))
		    		{
		    			p=this.userService.getUserById(p.getUserId());
		    			if(p.getInvalidLoginAttempts()==3)
		    				return "redirect:/account-locked";
		    			
		    			this.userService.logInvalidAttempt(p);
		    		}
    		}
    		return "redirect:/invalid-login";
    	}
    	else
    	{
    	//	System.out.println("Exists");
    		
    		System.out.println("User Type is" + p.getUserType());
    		userId=p.getUserId();
    	/*	model.addAttribute("userId",userId);
    		model.addAttribute("username",p.getUsername());
    		model.addAttribute("firstName",p.getFirstName());
    		model.addAttribute("userType",p.getUserType());*/
    		model.addAttribute("petCount",this.userService.getPetCount(userId));
			model.addAttribute("contactInfo",this.userService.isContactInfoSet(userId));
			model.addAttribute("listRequest",this.userService.listMatchingRequests(p));
			List<CommInterface> requestTable = this.commInterfaceService.getTableByOwnerId(userId);
			model.addAttribute("admin",new User());
			model.addAttribute("requestTable", requestTable);
			
			List<CommInterface> requestTableC = this.commInterfaceService.getTableByCaretakerId(userId);
  			System.out.println("list is "+ requestTableC);
  		    model.addAttribute("requestTableC", requestTableC);
  		    
			List<String> caretakerNames=new ArrayList<String>();
			for(CommInterface c:requestTable)
			{
				caretakerNames.add(this.userService.getUsernameFromId(c.getCaretakerId()));
			}
			model.addAttribute("caretakerNames",caretakerNames);
    		p.setLoginTime(new Date());
    		this.userService.updateUser(p);
    		
    		Profile profile=this.profileFactoryService.getProfileType(p.getUserType());
    		profile.setAccountLocked(p.isAccountLocked());
    		profile.setError(p.getError());
    		profile.setExpiresOnDate(p.getExpiresOnDate());
    		profile.setExpiryEmailSent(p.isExpiryEmailSent());
    		profile.setFirstName(p.getFirstName());
    		profile.setInvalidLoginAttempts(p.getInvalidLoginAttempts());
    		profile.setLastName(p.getLastName());
    		profile.setLoginTime(p.getLoginTime());
    		profile.setPassword(p.getPassword());
    		profile.setUserId(p.getUserId());
    		profile.setUsername(p.getUsername());
    		profile.setUserType(p.getUserType());
    		profile.setExpiryEmailSentDate(p.getExpiryEmailSentDate());

    		
    		model.addAttribute("profileObject",profile);
    		return  profile.getDashboard();
    	}
    		
    	/*	
    		if((p.getUserType()).equals("Admin"))
    		{
    			model.addAttribute("admin",new User());
    			return "adminDashboard";
    		}
    		else if((p.getUserType()).equals("Owner"))
    		{
    			
    			model.addAttribute("petCount",this.userService.getPetCount(userId));
    			model.addAttribute("contactInfo",this.userService.isContactInfoSet(userId));
    			return "ownerDashboard";
    		}
    		else 
    		{
    			model.addAttribute("petCount",this.userService.getPetCount(userId));
           		//	System.out.println("Pet count"+this.userService.getPetCount(userId));
    			System.out.println("Request list" +this.userService.listMatchingRequests(p) );
    			model.addAttribute("contactInfo",this.userService.isContactInfoSet(userId));
    			model.addAttribute("listRequest",this.userService.listMatchingRequests(p));
    			return "caretakerDashboard";
    		}
    	}*/
		
	}
  
    
    @RequestMapping(value= "/user/signup", method = RequestMethod.POST)
  	public String signupUser(Model model, @ModelAttribute("user") User p){
      	
     // 	System.out.println("in login");
    	
    	if(p.getFirstName()=="" || p.getLastName()=="")
    	{
    		model.addAttribute("invalidInput","Error: First and last name cannot be empty");
    		return "signup";
    	}
    	if(p.getUserType()=="")
    	{
    		model.addAttribute("invalidInput","Error: User role cannot be empty");
    		return "signup";
    	}
    	if(p.getPassword()=="")
    	{
    		model.addAttribute("invalidInput","Error: Password cannot be empty");
    		return "signup";
    	}
    	if(p.getUsername()=="")
    	{
    		model.addAttribute("invalidInput","Error: username cannot be empty");
    		return "signup";
    	}
      	boolean retVal=this.userService.addUser(p);
  		
      	
      	if(retVal)
      	{
      		model.addAttribute("invalidInput","Error: Username exists");
      		return "signup";
      	}
      	else
      	{
      	//	System.out.println("Exists");
      		int userId=	this.userService.getUserId(p.getUsername());
      		ResetToken r=new ResetToken();
      		r.setUserId(userId);
      		r.setUsername(p.getUsername());
      		r.setToken(null);
      		r.setExpiryTime(null);
      		
      		this.userService.createInitialTokenEntry(r);
      		return "redirect:/register-success";
      	}
  		
  	}
     
    @RequestMapping(value = "/register-success", method = RequestMethod.GET)
    public String registeredSuccessfully() {
       return "registerSuccess";
    }
    
    
    @RequestMapping(value = "/account-locked", method = RequestMethod.GET)
    public String displayAccountLockoutError() {
       return "accountLocked";
    }
    
    @RequestMapping(value = "/invalid-login", method = RequestMethod.GET)
    public String displayLoginError() {
       return "loginError";
    }
    
    
    @RequestMapping(value= "/user/dash")
   	public String displayDashboard(Model model, 
   			/*@RequestParam("userId")int userId, @RequestParam("userType") String userType,
   			@RequestParam("username") String username, @RequestParam("firstName") String firstName,
   			@RequestParam("lastName") String lastName*/
   			@ModelAttribute("user") User u){
    	     	
       		model.addAttribute("userId",u.getUserId());
       		
    		model.addAttribute("username",u.getUsername());
    		model.addAttribute("firstName",u.getFirstName());
    		model.addAttribute("userType",u.getUserType());
    		model.addAttribute("lastName",u.getLastName());
    		
    		model.addAttribute("listRequest",this.userService.listMatchingRequests(u));
			List<CommInterface> requestTable = this.commInterfaceService.getTableByOwnerId(u.getUserId());
			model.addAttribute("admin",new User());
			model.addAttribute("requestTable", requestTable);
			List<String> caretakerNames=new ArrayList<String>();
			for(CommInterface c:requestTable)
			{
				caretakerNames.add(this.userService.getUsernameFromId(c.getCaretakerId()));
			}
			model.addAttribute("caretakerNames",caretakerNames);
    		
    		
    		Profile profile=this.profileFactoryService.getProfileType(u.getUserType());
    	
    		profile.setFirstName(u.getFirstName());
    		profile.setLastName(u.getLastName());
    		profile.setUserId(u.getUserId());
    		profile.setUsername(u.getUsername());
    		profile.setUserType(u.getUserType());
    		model.addAttribute("profileObject",profile);
    		model.addAttribute("petCount",this.userService.getPetCount(u.getUserId()));
   			model.addAttribute("contactInfo",this.userService.isContactInfoSet(u.getUserId()));
   			model.addAttribute("petCount",this.userService.getPetCount(u.getUserId()));
       	
       		model.addAttribute("contactInfo",this.userService.isContactInfoSet(u.getUserId()));
   			
    		return  profile.getDashboard();
    		
       	
       	}
    
	@RequestMapping(value = "/passwordReset/{tokenId}/{username}", method = RequestMethod.GET)
	public String resetPassword(Model model,
			@PathVariable("tokenId") String tokenId,
			@PathVariable("username") String username) {
		System.out.println("In reset user");
		
		int userId=this.userService.getUserId(username);
		String token=this.userService.getResetToken(username);
		Date tokenExpiryTime=this.userService.getExpiryDate(username);
		User u1=this.userService.getUserById(userId);
		
		System.out.println(userId + " token="+token + " time="+tokenExpiryTime);
		Date currentTime=new Date();
		if(tokenId.equals(token))
		{
			if(currentTime.before(tokenExpiryTime))
			{
				model.addAttribute("user",u1);
				model.addAttribute("success",false);
				return "passwordRecoveryPage";
			}
		}
		
		return "invalidRecoveryLink";
	}
	
	@RequestMapping(value = "/user/updatePassword", method = RequestMethod.POST)
	public String updatePassword(Model model, @ModelAttribute("user") User u) {
		System.out.println("In update password");
		
		User temp1=this.userService.getUserById(u.getUserId());
		Date d=temp1.getLoginTime();
		
		u.setLoginTime(d);
		u.setAccountLocked(false);
		u.setError(null);
		u.setInvalidLoginAttempts(0);
		
		this.userService.updateUser(u);
		
		model.addAttribute("success",true);
		return "passwordRecoveryPage";
	}
	
	
	
	
}