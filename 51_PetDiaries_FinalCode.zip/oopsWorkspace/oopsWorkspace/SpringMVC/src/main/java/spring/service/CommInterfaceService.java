package spring.service;

import java.util.List;

import spring.model.CommInterface;

public interface CommInterfaceService {

	public boolean addCommInterface(CommInterface C);
	public void updateCommInterface(CommInterface C);
	public List<CommInterface> listCommInterfaces();
	public CommInterface getCommInterfaceById(int id);
	public void removeCommInterface(int id);
	
	public int getCommInterfaceCount(int id);
	public boolean isAgreementDone(int id);
	public List<CommInterface> getTableByOwnerId(int id);
	public List<Integer> getRequestsByOwnerId(int id);
	public List<Integer> getCaretakerByRequestId(int id);
	public List<CommInterface> getCommInterfaceListByRequestId(int id);
	public List<CommInterface> getTableByCaretakerId(int id);

}