package spring.service;

import java.util.List;

import spring.model.Profile;

public interface ProfileFactoryService
{
	public Profile getProfileType(String userType);
	
}