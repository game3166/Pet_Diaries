package spring.service;

import java.util.List;

import org.springframework.stereotype.Service;



import spring.model.Profile;
import spring.model.OwnerProfile;
import spring.model.CaretakerProfile;
import spring.model.AdminProfile;
@Service
public class ProfileFactoryServiceImpl implements ProfileFactoryService {
	
	

	@Override
	public Profile getProfileType(String userType) {
		Profile p=null;
		
		if(userType.equals("Owner"))
		{
			p=new OwnerProfile();
			p.setDashboard("ownerDashboard");
		}
		else if(userType.equals("Caretaker"))
		{
			p=new CaretakerProfile();
			p.setDashboard("caretakerDashboard");
		}
		else if(userType.equals("Admin"))
		{
			p=new AdminProfile();
			p.setDashboard("adminDashboard");
		}
				
		return p;
	}

	
}