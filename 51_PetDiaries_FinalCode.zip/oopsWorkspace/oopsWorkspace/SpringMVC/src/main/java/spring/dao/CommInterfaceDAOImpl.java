package spring.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import spring.model.CommInterface;

@Repository
public class CommInterfaceDAOImpl implements CommInterfaceDAO{

	private static final Logger logger = LoggerFactory.getLogger(CommInterfaceDAOImpl.class);

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	public boolean addCommInterface(CommInterface C)
	{
		boolean error=false;
		Session session = this.sessionFactory.getCurrentSession();
		
		try
		{
			session.save(C);
			//tx.commit();
			System.out.println("CommInterface DAO Impl Added CommInterface without exceptions");
		}
		catch(Exception e)
		{
			session.clear();
			System.out.println(e.getCause());
			error=true;
		}
		
		return error;
	}
	
	@Override
	public void updateCommInterface(CommInterface C)
	{
		Session session = this.sessionFactory.getCurrentSession();
		session.update(C);
		logger.info("CommInterface updated successfully, CommInterface Details="+C);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CommInterface> listCommInterfaces()
	{
		Session session = this.sessionFactory.getCurrentSession();
		List<CommInterface> CommInterfaceList = session.createQuery("from CommInterface").list();
		for(CommInterface C : CommInterfaceList){
			logger.info("CommInterface List::"+C);
		}
		return CommInterfaceList;
	}
	
	@Override
	public CommInterface getCommInterfaceById(int id)
	{
		Session session = this.sessionFactory.getCurrentSession();		
		CommInterface C = (CommInterface) session.load(CommInterface.class, new Integer(id));
		logger.info("CommInterface loaded successfully, CommInterface details="+C);
		return C;
	}
	
	@Override
	public void removeCommInterface(int id)
	{
		Session session = this.sessionFactory.getCurrentSession();
		CommInterface C = (CommInterface) session.load(CommInterface.class, new Integer(id));
		if(null != C){
			session.delete(C);
	
		}
		logger.info("CommInterface deleted successfully, CommInterface details="+C);
	}
	
	
	public int getCommInterfaceCount(int id)
	{
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "select count(*) from CommInterface where interfaceId="+String.valueOf(id);
		int count = ((Long) session.createQuery(hql).uniqueResult()).intValue();
		return count;
	}
	
	public boolean isAgreementDone(int id)
	{
		return true;
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public List<CommInterface> getCommInterfaceListByRequestId(int id){
		
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "from CommInterface where requestId="+String.valueOf(id);
		List<CommInterface> commInterfaceList= session.createQuery(hql).list();
		
		return commInterfaceList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getRequestsByOwnerId(int id)
	{
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "select requestId from CommInterface where ownerId="+String.valueOf(id);
		List<Integer> requests = session.createQuery(hql).list();
		System.out.println("reached here");
		return requests;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getCaretakerByRequestId(int id)
	{
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "select caretakerId from CommInterface where requestId="+String.valueOf(id);
		List<Integer> caretakers = session.createQuery(hql).list();
		
		return caretakers;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CommInterface> getTableByOwnerId(int id) {
		
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "from CommInterface where ownerId="+String.valueOf(id)+" ORDER BY requestId ASC";
		List<CommInterface> requestTable = session.createQuery(hql).list();
		return requestTable;
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public List<CommInterface> getTableByCaretakerId(int id){
		
		Session session = this.sessionFactory.getCurrentSession();
		String hql = "from CommInterface where caretakerId="+String.valueOf(id)+" ORDER BY requestId ASC";
		List<CommInterface> requestTable = session.createQuery(hql).list();
		return requestTable;
	}
	



	


	
}