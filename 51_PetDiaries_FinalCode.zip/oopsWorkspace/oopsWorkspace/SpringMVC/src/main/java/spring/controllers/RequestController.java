package spring.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Period;
import java.util.Date;
import spring.service.OwnerProfileService;

import spring.model.Request;
import spring.model.User;

import spring.service.RequestService;

@Controller
public class RequestController {
	
	private RequestService requestService;
	private OwnerProfileService ownerProfileService;
	@Autowired(required=true)
	@Qualifier(value="requestService")
	public void setRequestService(RequestService rs){
		this.requestService = rs;
	}
	
	@Autowired(required=true)
	//@Qualifier(value="ownerProfileService")
	public void setOwnerProfileService(OwnerProfileService rs){
		this.ownerProfileService = rs;
	}
	
	@RequestMapping(value = "/request", method = RequestMethod.GET)
	public String listRequest(Model model) {
		model.addAttribute("request", new Request());
		model.addAttribute("listRequest", this.requestService.listRequest());
		return "request";
	}
	
	//For add and update person both
	@RequestMapping(value= "/request/add", method = RequestMethod.POST)
	public String publishRequest(@ModelAttribute("request") Request r){
		
		r.setRequestState(1);
		if(r.getRequestId() == 0){
			//new person, add it
			this.requestService.publishRequest(r);
		}else{
			//existing person, call update
			this.requestService.editRequest(r);
		}
		
		return "request";
				
	}
	
	@RequestMapping("delete/{id}")
    public String deleteOldRequest(@PathVariable("id") int id){
		
        this.requestService.deleteOldRequest(id);
        return "redirect:/request";
    }
	
	@RequestMapping("/remove/{id}")
    public String removeOldRequest(@PathVariable("id") int id){
		
        this.requestService.deleteOldRequest(id);
        return "request";
    }
	
    @RequestMapping("/update/{id}/{username}")
    public String editRequest(@PathVariable("id") int id,@PathVariable("username") String username,
    		Model model, @ModelAttribute("request") Request r1)
    {
    	
    	Request r = this.requestService.getRequestById(id);
    	
    	//r.setRequestState(6);
    	
        model.addAttribute("request", this.requestService.getRequestById(id));
  //      model.addAttribute("listRequest", this.publishRequest(r));
        model.addAttribute("listRequest", this.requestService.listRequest());
        model.addAttribute("editRequest",true);
        model.addAttribute("ownerName",username);
        
        return "request";
    }
    
    @RequestMapping("/updateEdit/{id}")
    public String editReques1(@PathVariable("id") int id, Model model, @ModelAttribute("request") Request r1,
    		RedirectAttributes ra, @RequestParam("ownerName") String ownerName)
    {
    	
    	Request r = this.requestService.getRequestById(id);
    	//r.setRequestState(6);
    	
    	r.setPetType(r1.getPetType());
    	r.setPetBreed(r1.getPetBreed());
    	r.setPetName(r1.getPetName());
    	r.setFromDate(r1.getFromDate());
    	r.setToDate(r1.getToDate());
    	this.requestService.editRequest(r);
    	
      //  model.addAttribute("request", this.requestService.getRequestById(id));
    //    model.addAttribute("listRequest", this.publishRequest(r));
       // model.addAttribute("listRequest", this.requestService.listRequest());
        //model.addAttribute("editrequest",this.ownerProfileService.listRequestByOwnerId(id));
    	
    	
    	
    	ra.addFlashAttribute("request",this.requestService.getRequestById(id));
    	//ra.addAttribute("id",id);
    
      /* ra.addAttribute("listRequest", this.requestService.listRequest());
       ra.addAttribute("editrequest",this.ownerProfileService.listRequestByOwnerId(id));
    */
        String redirect="redirect:/user/login/edit/"+String.valueOf(id)+"/"+"Owner/"+ownerName;
        return redirect;
    }
    
    
    @RequestMapping("/update")
    public String updateRequest(@PathVariable("id") int id, Model model){
        model.addAttribute("request", this.requestService.getRequestById(id));
        model.addAttribute("listRequest", this.requestService.listRequest());
        return "redirect:/request";
    }
    
    
	@RequestMapping(value = "/validate/{id}", method = RequestMethod.GET)
    public String validateRequest(@PathVariable("id") int id,@ModelAttribute("request") Request r,
    		@ModelAttribute("user") User p,
    		Model model){
	
		r = this.requestService.getRequestById(id);			
		//model.addAttribute("ownerId", r.getOwnerId()); 
        //model.addAttribute("petType", r.getPetType());
        //model.addAttribute("petBreed", r.getPetBreed());
        //model.addAttribute("fromDate", r.getFromDate());
        //model.addAttribute("toDate", r.getToDate());
        r.setValidRequest(true);
        model.addAttribute("listRequest", this.publishRequest(r));
        model.addAttribute("listRequest", this.requestService.listRequest());
	    return "request";
    }
	
	public int requestHours(int id) throws ParseException
	{
		Request r = this.requestService.getRequestById(id);	
		Date date1= new SimpleDateFormat("MM/dd/yyyy").parse(r.getFromDate()); 
		Date date2= new SimpleDateFormat("MM/dd/yyyy").parse(r.getToDate()); 
		int hours = (int)((date2.getTime()-date1.getTime())/3600000);
		return hours;
	}
	
	@RequestMapping(value = "/complete/{id}", method = RequestMethod.GET)
    public String completeRequest(@PathVariable("id") int id,@ModelAttribute("request") Request r,
    		@ModelAttribute("user") User p,
    		Model model) throws ParseException{
		r = this.requestService.getRequestById(id);
        r.setHours(requestHours(id));
		r.setRequestState(3);
		this.requestService.editRequest(r);
       // model.addAttribute("listRequest", this.requestService.listRequest());
		model.addAttribute("requestId",id);
		model.addAttribute("requesthrs",r.getHours());
		model.addAttribute("completestate",r.getRequestState());
		return "caretakerDashboard";
	}


}