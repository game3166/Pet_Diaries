package com.chat.endpoint;

import java.io.IOException;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import javax.websocket.Session;

@ServerEndpoint(value = "/chat")
public class Endpoint {
   
	@OnOpen
	public void handleOpen(Session session)
	{
		System.out.println("Server Response: Client is Connected...");
	}
	
	@OnMessage
	public String handleMessage(String Msg)
	{
		System.out.println("Server response: Echo  "+ Msg);
		
		return Msg;
		
	}
	
	@OnClose
	public void handleClose(Session session) throws IOException
	{
		System.out.println("Server Response: Client is Disconnected...");
		
	}
	
	@OnError
	public void handleError(Throwable t)
	{
		t.printStackTrace();
	}
}
