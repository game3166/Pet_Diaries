package com.chat.endpoint;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import javax.websocket.Session;

@ServerEndpoint(value = "/chat")
public class Endpoint {
   
	static Set<Session> chatroomusers = Collections.synchronizedSet(new HashSet<Session>()); 
	
	@OnOpen
	public void handleOpen(Session usersession)
	{
		chatroomusers.add(usersession);
		System.out.println("Server Response: Client is Connected...");
	}
	
	@OnMessage
	public void handleMessage(String Msg, Session usersession) throws IOException
	{
		String username = (String)usersession.getUserProperties().get("username");
	
		if(username == null)
		{
			usersession.getUserProperties().put("username", Msg);
			usersession.getBasicRemote().sendText("System: you are now connected as: "+Msg);
		}
		else{
			Iterator<Session> iterator = chatroomusers.iterator();
			while(iterator.hasNext()) iterator.next().getBasicRemote().sendText(username + ": "+ Msg);
		}
		System.out.println("Server response: "+ username + ":" + Msg);	
	}
	
	@OnClose
	public void handleClose(Session usersession) throws IOException
	{
		chatroomusers.remove(usersession);
		System.out.println("Server Response: Client is Disconnected...");
		
	}
	
	@OnError
	public void handleError(Throwable t)
	{
		t.printStackTrace();
	}
}
